(function ($) {
  "use strict";

  $(function () {
    /*
     * Make the code pretty
     */

    window.prettyPrint && prettyPrint();

  });

} (jQuery));